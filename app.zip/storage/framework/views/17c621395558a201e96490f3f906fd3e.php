<?php $__env->startSection('content'); ?>
<div class="congrats-bg fullwidth">
    <div class="header fullwidth">
        <div class="wrapper">
            <div class="head-inn fullwidth text-center">
                <a href="https://www.jagershop.co.uk">
                <img src="<?php echo e(asset('assets/image/logo.svg')); ?>" alt="">
                </a>
            </div>
        </div>
    </div>
    <div class="congrates-sec shirt fullwidth">
        <div class="wrapper">
            <div class="congrates-main sec-center">
                <div class="gift-image">
                    <img src="<?php echo e(asset('assets/image/Jager-Kit-2.png')); ?>" alt="">
                </div>
                <h1>Congrats!</h1>
                <div class="congrates-txt">
                    <p>This shirts got your name on it!<span>You’ve won a limited edition</span> Jägermeister
                        football shirt.</p>
                </div>
                <div class="details-btn close congrates-btn">
                    <a href="<?php echo e(route('add-detail')); ?>">claim you prize</a>
                </div>
                <div class="terms-text">
                    <p>Terms and conditions apply <span>Visit <a href="#">jgr.ms/footballtandc</a> for
                            details</span></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/tshirt.blade.php ENDPATH**/ ?>