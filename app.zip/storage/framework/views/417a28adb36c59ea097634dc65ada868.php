<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="baseUrl" data-url="<?php echo e(url('/')); ?>"  id="baseUrl"/>
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/admin/images/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/admin/images/favicon.png')); ?>">
    <title>
       <?php echo e(config('app.name', 'Laravel')); ?> |  <?php echo e(__($pageTitle ?? __(''))); ?> 
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/nucleo-icons.css')); ?>"  crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/nucleo-svg.css')); ?>" crossorigin="anonymous" referrerpolicy="no-referrer" />    <!-- Font Awesome Icons -->
    <script src="<?php echo e(asset('assets/admin/js/fontawesome.js')); ?>" crossorigin="anonymous"></script>
    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/argon-dashboard.min.css')); ?>" crossorigin="anonymous" referrerpolicy="no-referrer" />    
    <script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"  crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/dataTables.dataTables.min.css')); ?>">
   
    <style>
        .bg-primary { background-color: #FB6340 !important; }
    </style>
</head>
<body class="<?php echo e($class ?? ''); ?>">


    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
        <?php if(in_array(request()->route()->getName(), ['sign-in-static', 'sign-up-static', 'login', 'register', 'recover-password', 'rtl', 'virtual-reality'])): ?>
            <?php echo $__env->yieldContent('content'); ?>
        <?php else: ?>
            <?php if(!in_array(request()->route()->getName(), ['profile', 'profile-static'])): ?>
                <div class="min-height-300 bg-primary position-absolute w-100"></div>
            <?php elseif(in_array(request()->route()->getName(), ['profile-static', 'profile'])): ?>
                <div class="position-absolute w-100 min-height-300 top-0" style="background-image: url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/profile-layout-header.jpg'); background-position-y: 50%;">
                    <span class="mask bg-primary opacity-6"></span>
                </div>
            <?php endif; ?>
            <?php echo $__env->make('admin.layouts.navbars.auth.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <main class="main-content border-radius-lg">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            <?php echo $__env->make('admin.components.fixed-plugin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/admin/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/core/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/plugins/smooth-scrollbar.min.js')); ?>"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <script src="<?php echo e(asset('assets/admin/js/dataTables.min.js')); ?>" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
       
    <?php echo $__env->yieldPushContent('js'); ?>;
    <?php echo $__env->yieldContent('js'); ?>;
</body>
</html><?php /**PATH /home/jagerfootball/public_html/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>