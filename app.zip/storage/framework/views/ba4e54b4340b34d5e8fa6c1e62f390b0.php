<div class="d-flex px-3 py-1 justify-content-center align-items-center">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
    <a class="text-sm font-weight-bold mb-0 ps-2"href="<?php echo e(route('admin.prizes.edit', $id)); ?>">Edit</a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-prize')): ?>
    <form id="deleteForm" class="mt-3" action="<?php echo e(route('admin.prizes.destroy', $id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <a href="#" class="text-sm font-weight-bold mb-1 ps-2" onclick="event.preventDefault(); document.getElementById('deleteForm').submit();">Delete</a>
    </form>
    
    <?php endif; ?>
</div><?php /**PATH /home/jagerfootball/public_html/resources/views/admin/prizes/action_button.blade.php ENDPATH**/ ?>