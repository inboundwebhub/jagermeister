<!DOCTYPE html>
<html>
<head>
    <title> <?php echo e(config('app.name', 'Laravel')); ?> |  <?php echo e(__($pageTitle ?? __(''))); ?> </title>
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" id="token">
    <meta name="baseUrl" data-url="<?php echo e(url('/')); ?>"  id="baseUrl"/>
    <link rel="icon" href="<?php echo e(asset('assets/image/apple-touch-icon.png')); ?>">

    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="cache-control" content="max-age=0"/>
    <meta http-equiv="cache-control" content="no-cache"/>

    <meta http-equiv="expires" content="0"/>
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT"/>
    <meta http-equiv="pragma" content="no-cache"/>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, maximum-scale=1.0, minimum-scale=0.5, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="HandheldFriendly" content="true">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="theme-color" content="#012B2C"/>

    <meta property="og:title" content="" />
    <meta property="og:image" content="<?php echo e(asset('assets/image/Social2.png')); ?>" />
    <meta property="og:url" content="https://thesecretisicecold.com/penaltyshootout" />
    <meta property="og:description" content="" />

    <meta name="twitter:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="">
    <meta name="twitter:card" content="">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    
    <meta content="Admin Dashboard" name="description" />
    <meta content="ThemeDesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <?php echo $__env->yieldPushContent('style-lib'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
    <?php echo $__env->yieldPushContent('script-lib'); ?>
</head>
<body>   
<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<script src="<?php echo e(asset('assets/js/script.js')); ?>"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"  referrerpolicy="no-referrer"></script>
<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"  referrerpolicy="no-referrer"></script>
<script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"  referrerpolicy="no-referrer"></script>
<?php echo $__env->yieldContent('js'); ?>

</body>
</html>

<?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/layouts/app.blade.php ENDPATH**/ ?>