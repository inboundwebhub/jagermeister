<?php $__env->startSection('content'); ?>
<div class="page-tow-bg fullwidth">

    <div class="header fullwidth">
        <div class="wrapper">
            <div class="head-inn fullwidth text-center">
                <a href="https://www.jagershop.co.uk">
                    <img src="<?php echo e(asset('assets/image/logo.svg')); ?>" alt="">
                </a>
            </div>
        </div>
    </div>

    <div class="congrates-sec unlucky fullwidth">
        <div class="wrapper">
            <div class="congrates-main sec-center">
                <!-- <div class="gift-image">
                    <img src="./image/voucher-image.png" alt="">
                </div> -->
                <h1>Unlucky!</h1>
                <div class="congrates-txt">
                    <p>Thank you for participating!<span>While you didn't win a prize this</span> <span>time, feel
                            free to explore the</span> <span>Jägermeister shop for more</span>great items. </p>
                </div>
                <div class="details-btn close congrates-btn">
                    <a href="https://www.jagershop.co.uk/">Visit the shop</a>
                </div>
                <div class="terms-text">
                    <p>Terms and conditions apply <span>Visit <a href="#">jgr.ms/footballtandc</a> for
                            details</span></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/unlucky.blade.php ENDPATH**/ ?>