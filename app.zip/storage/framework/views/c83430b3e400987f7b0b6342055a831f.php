
                    
<?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/admin/components/fixed-plugin.blade.php ENDPATH**/ ?>