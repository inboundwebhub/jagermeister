
<style>
    .dropdown-menu {
         display: none;
     }
 
    .show >.dropdown-menu {
         display: block;
     }
     .dropdown-menu {
    display: none;
    position: absolute;
    margin-top: 10px; /* adjust this value as needed */
}
 </style>


<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 min-h-screen"
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="<?php echo e(route('admin.dashboard')); ?>"
            target="_blank">
            <img src="<?php echo e(asset('assets/admin/images/logo-ct-dark.png')); ?>" class="navbar-brand-img h-100" alt="main_logo">
            <span class="ms-1 font-weight-bold"> <?php echo e(config('app.name', 'Laravel')); ?></span>
        </a>
    </div>
    <hr class="horizontal dark mt-0">
    <div class=" " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-tv-2 text-primary text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard</span>
                </a>
            </li>
             <li class="nav-item mt-3 d-flex align-items-center">
                
                <li class="nav-item mt-3">
                    <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">User Management</h6>
                </li>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::currentRouteName() == 'profile' ? 'active' : ''); ?>" href="<?php echo e(route('admin.profile')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Profile</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Tables</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::currentRouteName() == 'users' ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-calendar-grid-58 text-warning text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">User</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::currentRouteName() == 'prizes' ? 'active' : ''); ?>" href="<?php echo e(route('admin.prizes.index')); ?>">
                    <div
                    class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="ni ni-calendar-grid-58 text-warning text-sm opacity-10"></i>
                </div>
                    <span class="nav-link-text ms-1">Prize</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::currentRouteName() == 'live-prizes' ? 'active' : ''); ?>" href="<?php echo e(route('admin.live-prizes.index')); ?>">
                    <div
                    class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="ni ni-calendar-grid-58 text-warning text-sm opacity-10"></i>
                </div>
                    <span class="nav-link-text ms-1">Live Prize Table</span>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link<?php echo e(Route::currentRouteName() == 'prize-user' ? 'active' : ''); ?>" href="<?php echo e(route('admin.prize-user.index')); ?>">
                    <div
                    class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="ni ni-calendar-grid-58 text-warning text-sm opacity-10"></i>
                </div>
                    <span class="nav-link-text ms-1">Prize to User Table</span>
                </a>
            </li> 
             <li class="nav-item">
                <a class="nav-link<?php echo e(Route::currentRouteName() == 'game' ? 'active' : ''); ?>" href="<?php echo e(route('admin.game.index')); ?>">
                    <div
                    class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                    <i class="ni ni-trophy text-warning text-sm opacity-10"></i>
                </div>
                    <span class="nav-link-text ms-1">Game Setting</span>
                </a>
            </li> 
         
            
        </ul>
    </div>
</aside>

<!-- jQuery CDN -->


<!-- Your jQuery code -->


<?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/admin/layouts/navbars/auth/sidenav.blade.php ENDPATH**/ ?>