<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layouts.navbars.auth.topnav', ['title' => 'live_Prize'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mt-4 mx-4">
        <div class="col-xxl-15">
            <div id="alert">
                <div class="px-4 pt-4">
                    <?php if($message = session()->has('succes')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <p class="text-white mb-0"><?php echo e(session()->get('succes')); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if($message = session()->has('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <p class="text-white mb-0"><?php echo e(session()->get('error')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>                
            </div>  
            <div class="card mb-7">
                <div class="card-header pb-0">
                    <h6>Prizes </h6>
                </div>
                <div class="card-body px-4 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">Prize ID</th>

                                    <th class="text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">prize type</th>

                                    <th class="text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">prize number</th>

                                    <th class="text-uppercase text-center text-secondary text-xxs font-weight-bolder opacity-7">Assigned</th>
                                    
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $livePrizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle text-center ">

                                        <div class="d-flex align-items-center justify-content-center text-center px-3 py-1">
                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm"><?php echo e($prize->id); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td class="align-middle text-center ">
                                        <div class="d-flex align-items-center justify-content-center text-center px-3 py-1">
                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm"><?php echo e($prize->prize_type); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="align-middle text-center ">

                                        <div class="d-flex align-items-center justify-content-center text-center px-3 py-1">
                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm"><?php echo e($prize->prize_number); ?></h6>
                                            </div>
                                        </div>
                                        
                                    </td>
                                    <td class="align-middle text-center ">
                                        <div class="d-flex align-items-center justify-content-center text-center px-3 py-1">
                                            <div class="d-flex flex-column justify-content-center">
                                                <h6 class="mb-0 text-sm"><?php echo e($prize->assigned); ?></h6>
                                            </div>
                                        </div>                                        
                                    </td>
                                   
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            </tbody>
                        </table>
                    </div>
                </div>
                 <!-- Pagination links -->
                 <div class="card-footer d-flex justify-content-end">
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $(document).ready(function () {
        $('.table').DataTable();
        
    });
</script>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xammp\htdocs\jagermeister\resources\views/admin/live_prizes/index.blade.php ENDPATH**/ ?>