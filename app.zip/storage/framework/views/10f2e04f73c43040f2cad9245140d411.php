
                    
<?php /**PATH /home/jagerfootball/public_html/resources/views/admin/components/fixed-plugin.blade.php ENDPATH**/ ?>